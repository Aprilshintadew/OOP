/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tugasoop4;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class TugasOOP4 {

    public static void main(String[] args) {
        ArrayList<String> Kota = new ArrayList<String>();
        Kota.add("Bogor");
        Kota.add("Surabaya");
        Kota.add("Bali");
        Kota.add("Manado");
        Kota.add("Jakarta");
        Kota.add("Medan");
        cout("----------Kota-----------");
        System.out.println(Kota);
        cout("Jumlah Kota  : "+ String .valueOf(Kota.size()));
    }
    static void cout (String s)
    {
        System.out.println(s);
}
    
}