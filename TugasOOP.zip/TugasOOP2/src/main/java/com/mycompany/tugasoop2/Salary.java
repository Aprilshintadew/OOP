/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugasoop2;

/**
 *
 * @author User
 */
public class Salary extends Karyawan {
    double salary;
    public Salary (double salary, String namaKaryawan,
                  String nik,String email,String alamat){
    super (namaKaryawan,nik,email,alamat);
    this.salary = salary;
}
    


    @Override
    public void tampilkandata() {
   cout("Nama Karyawan   : "+ getNamaKaryawan());
   cout("Nik             : "+ getNik());
   cout("Email           : "+ getEmail());
   cout("Alamat          : "+ getAlamat());
   cout("Salary          : "+ String.valueOf((int) salary));
    }

void cout (String s)
{
System.out.println(s);
}
}
