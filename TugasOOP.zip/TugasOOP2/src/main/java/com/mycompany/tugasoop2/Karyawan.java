/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugasoop2;

/**
 *
 * @author User
 */
public abstract class Karyawan {
    String namaKaryawan,nik,email,alamat;

    public Karyawan(String namaKaryawan, String nik, String email, String alamat) {
        this.namaKaryawan = namaKaryawan;
        this.nik = nik;
        this.email = email;
        this.alamat = alamat;
    }

    public String getNamaKaryawan() {
        return namaKaryawan;
    }

    public void setNamaKaryawan(String namaKaryawan) {
        this.namaKaryawan = namaKaryawan;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

   
    public abstract void tampilkandata();
    

}
    
