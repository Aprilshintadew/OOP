/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tugasoop2;

/**
 *
 * @author User
 */
public class TugasOOP2 {

    public static void main(String[] args) {
       
        Karyawan k1 = new Salary (55000000, "Aprilia Shinta Dewi","111222333","apriliashintad@gmail.com","Comas");
        k1.tampilkandata();
    }
}
