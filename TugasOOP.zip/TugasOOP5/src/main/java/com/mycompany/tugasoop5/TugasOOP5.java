/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tugasoop5;

 class TokoKomputer {
    public void beliKomponen(){
        System.out.println("komponen Yang Akan Dibeli  : ");
    }  
}
class Vga extends TokoKomputer{

    @Override
    public void beliKomponen() {
       System.out.println("-VGA Nvidia"); 
    }
    
}
class Processor extends TokoKomputer{

    @Override
    public void beliKomponen() {
    System.out.println("-PROCESSOR Intel");
    }
    
}


class TugasOOP5 {

    public static void main(String[] args) {
       TokoKomputer Toko = new TokoKomputer();
       TokoKomputer myCart1 = new Vga();
       TokoKomputer myCart2 = new Processor();
       Toko.beliKomponen();
       myCart1.beliKomponen();
       myCart2.beliKomponen();
       
    }
}
