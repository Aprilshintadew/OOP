/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugasoop1;

/**
 *
 * @author User
 */
public class SiswaInter {
    private Siswa siswa;
    public SiswaInter (Siswa siswa)
    {
        this.siswa = siswa;
    }   
    void printNama (String s)
    {
        this.siswa.TampilkanNama(s);
    }
     void printKelas (String s)
    {
        this.siswa.TampilkanKelas(s);
    }
     void printJurusan (String s)
    {
        this.siswa.TampilkanJurusan(s);
    }  
     void printNilai (String s)
    {
        this.siswa.TampilkanNilai(s);
    }  
}

