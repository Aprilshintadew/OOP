/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugasoop1;

/**
 *
 * @author User
 */
public interface Siswa {
    void TampilkanNama(String nama);
    void TampilkanKelas(String kelas);
    void TampilkanJurusan(String jurusan);
    void TampilkanNilai(String nilai);

    
    
}
