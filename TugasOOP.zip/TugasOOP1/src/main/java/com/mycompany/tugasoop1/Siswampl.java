/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugasoop1;

/**
 *
 * @author User
 */
public class Siswampl implements Siswa {

    @Override
    public void TampilkanNama(String nama) {
       cout ("Nama : "+ nama); 
    }

    @Override
    public void TampilkanKelas(String kelas) {
        cout ("Kelas : "+ kelas);
    }
    @Override
    public void TampilkanJurusan(String jurusan) {
       cout ("Jurusan : "+ jurusan);
    }

    @Override
    public void TampilkanNilai(String nilai) {
         cout ("Nilai : "+ nilai);
    }
   void cout (String s)
    
   {
       System.out.println(s);
}
}